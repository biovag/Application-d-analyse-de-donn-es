import streamlit as st
import pandas as pd
from wordcloud import WordCloud
import matplotlib.pyplot as plt

def run():
    st.subheader("📝 Analyse textuelle")
    uploaded_file = st.file_uploader("Chargez un fichier CSV", type=["csv"])
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        text_col = st.selectbox("Colonne de texte", df.select_dtypes(include='object').columns)
        text = " ".join(df[text_col].dropna())
        wordcloud = WordCloud(width=800, height=400, background_color='white').generate(text)
        fig, ax = plt.subplots()
        ax.imshow(wordcloud, interpolation='bilinear')
        ax.axis('off')
        st.pyplot(fig)
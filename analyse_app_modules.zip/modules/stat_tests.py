import streamlit as st
import pandas as pd
from scipy import stats

def run():
    st.subheader("📊 Tests statistiques")
    uploaded_file = st.file_uploader("Chargez un fichier CSV", type=["csv"])
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        cols = df.select_dtypes(include='number').columns.tolist()
        var1 = st.selectbox("Variable 1", cols)
        var2 = st.selectbox("Variable 2", cols)
        test = st.selectbox("Test à effectuer", ["t-test", "ANOVA", "Correlation"])
        if st.button("Exécuter le test"):
            if test == "t-test":
                result = stats.ttest_ind(df[var1], df[var2], nan_policy='omit')
            elif test == "ANOVA":
                result = stats.f_oneway(df[var1], df[var2])
            else:
                result = stats.pearsonr(df[var1], df[var2])
            st.write(result)
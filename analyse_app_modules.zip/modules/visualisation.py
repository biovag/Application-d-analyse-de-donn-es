import streamlit as st
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

def run():
    st.subheader("📉 Visualisation")
    uploaded_file = st.file_uploader("Chargez un fichier CSV", type=["csv"])
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        col = st.selectbox("Choisissez une variable numérique", df.select_dtypes(include='number').columns)
        fig, ax = plt.subplots()
        sns.histplot(df[col], kde=True, ax=ax)
        st.pyplot(fig)
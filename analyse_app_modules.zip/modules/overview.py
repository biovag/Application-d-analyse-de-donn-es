import streamlit as st
import pandas as pd

def run():
    st.subheader("📊 Aperçu des données")
    uploaded_file = st.file_uploader("Chargez un fichier CSV", type=["csv"])
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        st.write("Aperçu des données", df.head())
        st.write("Dimensions :", df.shape)
        st.write("Types de données :", df.dtypes)
        st.write("Valeurs manquantes :", df.isnull().sum())
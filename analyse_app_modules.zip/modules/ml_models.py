import streamlit as st
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression, LogisticRegression
from sklearn.metrics import mean_squared_error, accuracy_score

def run():
    st.subheader("🤖 Modèles prédictifs")
    uploaded_file = st.file_uploader("Chargez un fichier CSV", type=["csv"])
    if uploaded_file:
        df = pd.read_csv(uploaded_file)
        target = st.selectbox("Variable cible", df.columns)
        features = st.multiselect("Variables explicatives", [col for col in df.columns if col != target])
        model_type = st.radio("Type de modèle", ["Régression linéaire", "Régression logistique"])
        if st.button("Entraîner le modèle"):
            X = df[features]
            y = df[target]
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
            if model_type == "Régression linéaire":
                model = LinearRegression()
                model.fit(X_train, y_train)
                preds = model.predict(X_test)
                st.write("MSE:", mean_squared_error(y_test, preds))
            else:
                model = LogisticRegression(max_iter=1000)
                model.fit(X_train, y_train)
                preds = model.predict(X_test)
                st.write("Accuracy:", accuracy_score(y_test, preds))